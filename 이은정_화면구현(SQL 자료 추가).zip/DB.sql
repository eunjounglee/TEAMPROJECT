-- --------------------------------------------------------
-- 호스트:                          localhost
-- 서버 버전:                        5.7.25 - MySQL Community Server (GPL)
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- javaproject 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `javaproject` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `javaproject`;

-- 테이블 javaproject.sports_article 구조 내보내기
CREATE TABLE IF NOT EXISTS `sports_article` (
  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '게시물번호',
  `TITLE` varchar(100) DEFAULT NULL COMMENT '게시물제목',
  `CONTENT` varchar(500) DEFAULT NULL COMMENT '게시물내용',
  `HIT` int(11) DEFAULT NULL COMMENT '조회수',
  `ID2` varchar(50) DEFAULT NULL COMMENT '아이디',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- 테이블 데이터 javaproject.sports_article:~43 rows (대략적) 내보내기
/*!40000 ALTER TABLE `sports_article` DISABLE KEYS */;
INSERT INTO `sports_article` (`ID`, `TITLE`, `CONTENT`, `HIT`, `ID2`) VALUES
	(1, 'whatsup', '??', 2, NULL),
	(2, 'this is second try', 'second time writing something', 1, NULL),
	(4, 'Tmr is Friday', 'Friday!!!!!', 6, NULL),
	(5, 'Saturday', '', 0, NULL),
	(6, 'Sunday', '', 0, NULL),
	(7, 'Monday', 'Monday EWWWW', 0, NULL),
	(8, 'Tuesday', '', 7, NULL),
	(9, 'Wednesday', '', 0, NULL),
	(10, 'Thursday again', '', 34, NULL),
	(11, 'blahblahblahblah', 'ddd', 12, NULL),
	(13, '??', 'asdasd', 1, NULL),
	(14, 'bbc.in/2UJRLgL ', 'It\'s almost time for the PFA Player of the Year shortlist to be announced.\r\n\r\nHere\'s who our pundits are backing.', 1, NULL),
	(15, '오늘은', '금요일', 0, NULL),
	(16, '최근 연예가 핫이슈 적중시킨 \'찌라시\'의 모든 것', '찌라시의 실체, 어떻게 만들어지고 유포되며 연예계에 어떤 영향력을 미치는지 등 궁금증을 낱낱이 풀어봤다.\r\n\r\nhttps://www.mk.co.kr/news/sports/view/2013/03/239015/', 1, NULL),
	(17, '찌라시', '흥미성, 낚시성 위주의 삼류 기사를 실은 미디어를 뜻하는 속어\r\n\r\nhttps://namu.wiki/w/%EC%B0%8C%EB%9D%BC%EC%8B%9C\r\n\r\n\r\n\r\nㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ', 2, NULL),
	(18, '토트넘 영웅 \'손\' 이쯤되면 신', '손흥민 전반 10분 만에 2골…시즌 19, 20호\r\n챔스 통산 12골로 아시아 선수 최다골 경신\r\n토트넘, 57년 만의 4강 진출 견인차\r\n경고누적으로 4강 1차전 결장 아쉬움\r\n\r\n원문보기: \r\nhttp://www.hani.co.kr/arti/sports/soccer/890480.html#csidx946b1032517b9f5926172af94394d3b \r\n\r\n\r\n손흥민 짱짱찡', 2, NULL),
	(19, '토트넘 홋스퍼 티켓', '일정입니다\r\n\r\nhttps://www.stubhub.co.kr/%E1%84%90%E1%85%A9%E1%84%90%E1%85%B3%E1%84%82%E1%85%A5%E1%86%B7-%E1%84%92%E1%85%A9%E1%86%BA%E1%84%89%E1%85%B3%E1%84%91%E1%85%A5-%E1%84%90%E1%85%B5%E1%84%8F%E1%85%A6%E1%86%BA/ca1259', 2, NULL),
	(20, '리버풀 살라흐의 \'쐐기 골\' 세리머니', '(리버풀 EPA=연합뉴스) 리버풀 무함마드 살라흐(왼쪽 두 번째)가 14일(현지시간) 영국 리버풀 안필드에서 열린 첼시와의 2018-2019 잉글랜드 프로축구 프리미어리그(EPL) 34라운드 경기에서 팀의 두 번째 골을 넣고 동료들 사이에서 세리머니를 펼치고 있다. 이날 사디오 마네와 살라흐의 연속골에 힘입어 2-0 완승을 한 리버풀은 승점 85로 맨체스터 시티(승점 83)를 제치고 리그 선두에 복귀했다.', 1, NULL),
	(21, 'Hang Time Podcast: Recapping first week of NBA playoffs', 'John Schuhmann and I discuss every first-round series before pivotal Game 3s and 4s this weekend.\r\n\r\nThen Shaun Powell of NBA.com joins to help us analyze the Warriors vs. Clippers series before Game 3 on Thursday night. We break down the Clippers\' historic Game 2 comeback, Kevin Durant\'s mindset, and the Warriors\' level of vulnerability after DeMarcus Cousins\' season-ending injury.', 0, NULL),
	(22, '휴스턴 라인업', 'http://bdata.7m.com.cn/basketball_team_data/28/kr/index.shtml', 2, NULL),
	(23, '농구: NBA 2018/2019 라이브 -결과, 일정, 순위 - 스코어보드 닷컴', 'https://www.scoreboard.com/kr/basketball/usa/nba/', 2, NULL),
	(24, '[NBA 프리뷰] 휴스턴 vs 토론토', '관점 포인트\r\n리그 최고의 창 vs. 리그 최고의 방패\r\n\r\n\r\nhttp://blog.naver.com/PostView.nhn?blogId=kevinkim911&logNo=221480974358&parentCategoryNo=&categoryNo=13&viewDate=&isShowPopularPosts=true&from=search', 2, NULL),
	(25, '골든 스테이트 라인업', 'https://bdata.7m.com.cn/basketball_team_data/25/kr/index.shtml', 1, NULL),
	(26, '골든스테이트, 1쿼터에만 51득점…NBA 최고기록 ', '(서울=연합뉴스) 김경윤 기자 = 미국 프로농구(NBA) 골든스테이트 워리어스가 NBA 역대 1쿼터 최다 득점 기록을 갈아치웠다.\r\n\r\n골든스테이트는 16일(한국시간) 미국 콜로라도주 펩시센터에서 열린 NBA 2018-2019 정규리그 덴버 너기츠와 원정경기에서 1쿼터에만 51득점을 올리며 142-111로 완승했다.\r\n\r\n디펜딩 챔피언 골든스테이트의 화력은 무서웠다.', 1, NULL),
	(27, 'NBA 순위 (동부)', '1. 밀워키\r\n2. 토론토\r\n3. 필라데피아\r\n4. 보스턴\r\n5. 인디애나', 2, NULL),
	(28, 'NBA 드래프트 역대 1순위', '2014\r\n클리블랜드 캐벌리어스\r\n앤드류 위긴스\r\n캐나다\r\n가드/포워드\r\n\r\n2015\r\n미네소타 팀버울브스\r\n칼 앤서니 타운스\r\n미국 [12]\r\n센터\r\n\r\n2016\r\n필라델피아 세븐티식서스\r\n벤 시몬스\r\n호주\r\n가드/ 포워드[13]\r\n\r\n2017\r\n필라델피아 세븐티식서스\r\n마켈 펄츠\r\n미국\r\n가드[14]\r\n\r\n2018\r\n피닉스 선즈\r\n디안드레 에이튼\r\n바하마\r\n센터', 1, NULL),
	(29, 'NBA의 동부지구와 서부지구 구분', 'http://blog.daum.net/_blog/BlogTypeView.do?blogid=0ZrSk&articleno=1411&categoryId=46®dt=20140430001617\r\n\r\n\r\n수정', 7, NULL),
	(30, '전국체전 박태환, 자유형 200ｍ 예선 1위로 결승 진출', '박태환(인천시청)이 전국체육대회 수영 남자 일반부 자유형 200ｍ 예선을 1위로 통과했다. \r\n\r\n박태환은 15일 전북 전주 완산수영장에서 열린 제99회 전국체전 수영 남자 일반부 자유형 200ｍ 예선 2조에서 1분 51초 32의 기록으로 결선에 진출했다. \r\n\r\n박태환이 가진 한국기록 1분 44초 80, 대회 신기록 1분 45초 01에는 못 미친다. ', 0, NULL),
	(31, 'KBO 2019시즌 연봉순위 및 FA계약 현황', 'https://m.blog.naver.com/calodoo/221398950003', 0, NULL),
	(32, '이대호, 2018년 25억원 프로야구 연봉킹  [출처: 중앙일보] 이대호, 2018년 25억원 프로야구 연봉킹', 'https://news.joins.com/article/22371653', 0, NULL),
	(33, '호주프로야구에 최초로 한국 팀 생긴다  [출처: 중앙일보] 호주프로야구에 최초로 한국 팀 생긴다', 'https://news.joins.com/article/22643419', 0, NULL),
	(34, '2018 프로야구 최종 순위가 나왔다', 'https://www.huffingtonpost.kr/entry/story_kr_5bc3005de4b01a01d68b649c', 0, NULL),
	(35, '‘프로야구 맞아?’…반복되는 황당 판정에 심판 자질 ‘논란’ / KBS뉴스(News)', 'https://www.youtube.com/watch?v=sVdFkhsSNDA', 0, NULL),
	(36, '“아이들에게 수영을 가르치다 보면 저절로 힐링이 돼요.”', 'https://1boon.kakao.com/prismtv/swimmer', 0, NULL),
	(37, '매일 수영을 하면 생기는 놀라운 건강 효과 5가지 ', 'https://www.youtube.com/watch?v=4xPrHWfnHdg', 0, NULL),
	(38, '유럽선 옷·신발 착용 `생존수영`…한국선 물장구치는 수준', 'https://www.mk.co.kr/news/special-edition/view/2015/04/345036/', 0, NULL),
	(39, '[수영상식] 수영 경기 종목 (1) 영법별 경영 ', 'https://m.blog.naver.com/PostView.nhn?blogId=d-eyeofsoul&logNo=221244286702&proxyReferer=https%3A%2F%2Fwww.google.com%2F', 0, NULL),
	(40, '[수영상식] 수영 경기 종목 (2) 계영 혼계영 개인혼영 (경영 종목)', 'https://m.blog.naver.com/PostView.nhn?blogId=d-eyeofsoul&logNo=221245174728&proxyReferer=https%3A%2F%2Fwww.google.com%2F', 0, NULL),
	(41, '리우올림픽 최고의 꿀알바…‘수영 경기 안전요원’', 'https://www.mk.co.kr/news/sports/view/2016/08/567280/', 0, NULL),
	(42, '수영경기의 레인 배정은 어떻게 결정되나요?', 'http://lg-sl.net/product/infosearch/curiosityres/readCuriosityRes.mvc?curiosityResId=HODA2010040036', 0, NULL),
	(43, '수영 반칙 행위 안내 및 수영 경기 용어 정리', 'https://filer.tistory.com/131', 0, NULL),
	(44, '[제15회 DB손해보험 프로미 오픈] \'디펜딩 챔피언\' 전가람 “아직 늦지 않았습니다”', '2라운드를 마친 전가람은 “대회 시작 전에 감기에 걸려 고생했는데 조금씩 좋아지고 있다”고 전하면서 “다만 시즌 전에 클럽 샤프트를 교체했는데 거리감을 맞추는 데 조금 애를 먹었다. 1, 2라운드를 통해 어느정도 적응했다”라고 말했다.\r\n\r\n \r\n\r\n전날 이븐파 공동 40위에서 이날 공동 30위권으로 순위를 끌어올렸지만 선두권과는 여전히 7타 이상 벌어져 있다. 하지만 그는 지난해 좋은 경험을 데자뷰하고 있다.\r\n\r\n \r\n\r\n지난해 본 대회를 통해 첫 우승을 차지할 때도 전가람은 2라운드까지 3언더파 141타 공동 27위였다. 그때까지 그의 우승을 점친 사람은 거의 없었다. 전가람은 3라운드부터 힘을 냈고 3라운드와 최종라운드에서 각각 6타씩 이틀동안 총 12타를 줄여 우승컵을 품에 안았다.\r\n\r\n \r\n\r\n전가람은 “아직 늦지 않았다. ‘몰아치기’하면 ‘전가람’이라는 것은 남은 라운드를 통해 보여드리겠다”며 각오를 다졌다', 0, NULL),
	(45, '숨고 사용 팁 다음 몇가지 질문에 답변해주시면, 고수님이 요청에 적합한 맞춤 견적서를 보내드려요.  견적서에는 가격은 물론 프로필, ', '\r\nhttps://soomgo.com/hire/%EA%B3%A8%ED%94%84?utm_source=google&utm_medium=cpc&utm_campaign=%EA%B3%A8%ED%94%84&utm_content=lesson&utm_term=%2B%EA%B3%A8%ED%94%84%2B%EB%A0%88%EC%8A%A8%2B%ED%94%84%EB%A1%9C&gclid=Cj0KCQjw4-XlBRDuARIsAK96p3DRNUtPpZspRB6N2cv5-ln0BMWv7nI9X41tW8KmMTQPZoOR_1It14gaAngREALw_wcB', 0, NULL);
/*!40000 ALTER TABLE `sports_article` ENABLE KEYS */;

-- 테이블 javaproject.sports_member 구조 내보내기
CREATE TABLE IF NOT EXISTS `sports_member` (
  `ID` varchar(50) DEFAULT NULL COMMENT '아이디',
  `PW` varchar(50) DEFAULT NULL COMMENT '비밀번호',
  `NAME` varchar(10) DEFAULT NULL COMMENT '회원이름'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 javaproject.sports_member:~0 rows (대략적) 내보내기
/*!40000 ALTER TABLE `sports_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `sports_member` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
